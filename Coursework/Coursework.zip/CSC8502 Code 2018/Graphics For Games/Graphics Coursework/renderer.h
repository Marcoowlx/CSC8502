#pragma once

#include "../../nclgl/OGLRenderer.h"
#include "../../nclgl/Camera.h"
#include "../../nclgl/HeightMap.h"
#include "../../nclgl/MD5Mesh.h"
#include "../../nclgl/MD5Node.h"
#include "../../nclgl/SceneNode.h"
#include "CubeRobot.h"
#include "TextMesh.h"
#include "ParticleEmitter.h"


#define SHADOWSIZE 2048
#define POST_PASSES 10

class Renderer : public OGLRenderer
{
public:
	Renderer(Window &parent);
	virtual ~Renderer(void);

	virtual void RenderScene();
	virtual void UpdateScene(float msec);

protected:
	void DrawHeightmap();
	void DrawWater();
	void DrawSkybox();
	void DrawMesh();
	void DrawShadowScene();
	void DrawCombineScene();
	void DrawNode(SceneNode *n);
	void DrawCube();
	void DrawText(const std::string &text, const Vector3 &position, const float size = 10.0f, const bool perspective = false);
	void DrawFps();
	void DrawEmitter();
	void CalculateFrameRate();
	void UpdateLight(Light* l);
	void UpdateKnight();
	void UpdateCamera();
	void UpdateCameraAuto(float msec);

	

	Shader* lightShader; 
	Shader* reflectShader; 
	Shader* skyboxShader;
	Shader* cubeShader;
	Shader* sceneShader; 
	Shader* shadowShader; 
	Shader* textShader; 
	Shader* emitterShader; 

	//Shadow
	GLuint shadowTex;
	GLuint shadowFBO;

	//Skybox
	GLuint cubeMap;

	//hellKnight
	MD5FileData* hellData;
	MD5Node* hellNode;

	//HeightMap
	HeightMap* heightMap;
	Mesh* quad;
	Mesh* floor;

	//Light
	Light* flight;

	//Camera
	Camera* camera;
	
	//Create the sphere
	SceneNode* root;
	SceneNode* lightSphere;

	float waterRotate; //Water rotation

	Font*	basicFont;//DrawText Font

	//Emitter
	void	SetShaderParticleSize(float f);	//And a new setter
	ParticleEmitter*	emitter;	//A single particle emitter

	bool pause = false;//Controll pause and continue

	int camPos = 0;//Controll the camera position;

	int Lightcount = 0;//Control light colour&skybox

	Vector3 newPos;//real time sphere pos

	bool camauto=false;//whether move the camera automatically
	
};

