﻿#include "renderer.h"
#include "string.h"
string str_fps;

Renderer::Renderer(Window &parent) : OGLRenderer(parent)
{
	//DrawText
	basicFont = new Font(SOIL_load_OGL_texture(TEXTUREDIR"tahoma.tga", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_COMPRESS_TO_DXT), 16, 16);

    //Sphere
	CubeRobot::CreateCube();
	root = new SceneNode();
	lightSphere = new CubeRobot();
	lightSphere->SetTransform(Matrix4::Translation(Vector3(2000,2500,2500)));
	root->AddChild(lightSphere);
	
	//Emitter
	emitter = new ParticleEmitter();

	//Camera
	camera = new Camera();
	camera->SetPosition(Vector3(RAW_WIDTH*HEIGHTMAP_X / 2.0f, 500.0F, RAW_WIDTH*HEIGHTMAP_X));

	//Heightmap
	heightMap = new HeightMap(TEXTUREDIR"terrain.raw");
	quad = Mesh::GenerateQuad();

	//HellKnight
	hellData = new MD5FileData(MESHDIR"hellknight.md5mesh");
	hellNode = new MD5Node(*hellData);
	hellData->AddAnim(MESHDIR"idle2.md5anim");
	hellNode->PlayAnim(MESHDIR"idle2.md5anim");
	

	//Shader
	cubeShader = new Shader(SHADERDIR"SceneVertex.glsl", SHADERDIR"SceneFragment.glsl");
	reflectShader = new Shader(SHADERDIR"PerPixelVertex.glsl", SHADERDIR"reflectFragment.glsl");
	skyboxShader = new Shader(SHADERDIR"skyboxVertex.glsl", SHADERDIR"skyboxFragment.glsl");
	lightShader = new Shader(SHADERDIR"PerPixelVertex.glsl", SHADERDIR"PerPixelFragment.glsl");
	sceneShader = new Shader(SHADERDIR"shadowscenevert.glsl", SHADERDIR"shadowscenefrag.glsl");
	shadowShader = new Shader(SHADERDIR"shadowVert.glsl", SHADERDIR"shadowFrag.glsl");
	textShader= new Shader(SHADERDIR"TexturedVertex.glsl", SHADERDIR"TexturedFragment.glsl");
	emitterShader = new Shader(SHADERDIR"vertex.glsl",SHADERDIR"fragment.glsl",SHADERDIR"geometry.glsl");

	//ShaderLink
	if (!cubeShader->LinkProgram()|| 
		!sceneShader->LinkProgram() || 
		!shadowShader->LinkProgram() || 
		!reflectShader->LinkProgram() || 
		!lightShader->LinkProgram() || 
		!skyboxShader->LinkProgram()|| 
		!textShader->LinkProgram() || 
		!emitterShader->LinkProgram()) {
		return;
	}
	
	//Light
	flight = new Light(Vector3(2000.0f, 2000.0f, 2000.0f), Vector4(1, 1, 1, 1), 7000.0f);


	//Heightmap & Water
	quad->SetTexture(SOIL_load_OGL_texture(TEXTUREDIR"water.TGA", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS));
	heightMap->SetTexture(SOIL_load_OGL_texture(TEXTUREDIR"brick1.JPG", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS));
	heightMap->SetBumpMap(SOIL_load_OGL_texture(TEXTUREDIR"Barren RedsDOT3.JPG", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS));

	//SkyBox
	cubeMap = SOIL_load_OGL_cubemap(TEXTUREDIR"rusted_west.jpg", 
		TEXTUREDIR"rusted_east.jpg", 
		TEXTUREDIR"rusted_up.jpg", 
		TEXTUREDIR"rusted_down.jpg", 
		TEXTUREDIR"rusted_south.jpg", 
		TEXTUREDIR"rusted_north.jpg", 
		SOIL_LOAD_RGB, SOIL_CREATE_NEW_ID, 0);

	if (!cubeMap || !quad->GetTexture() || !heightMap->GetTexture() || !heightMap->GetBumpMap()) {
		return;
	}

	//SetRepeating
	SetTextureRepeating(quad->GetTexture(), true);
	SetTextureRepeating(heightMap->GetTexture(), true);
	SetTextureRepeating(heightMap->GetBumpMap(), true);

	//Shadow
	glGenTextures(1, &shadowTex);
	glBindTexture(GL_TEXTURE_2D, shadowTex);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, SHADOWSIZE, SHADOWSIZE, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_R_TO_TEXTURE);

	glBindTexture(GL_TEXTURE_2D, 0);

	glGenFramebuffers(1, &shadowFBO);

	glBindFramebuffer(GL_FRAMEBUFFER, shadowFBO);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex, 0);

	glDrawBuffer(GL_NONE);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);

	waterRotate = 0.0f;

	projMatrix = Matrix4::Perspective(1.0f, 15000.0f, (float)width / (float)height, 45.0f);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);

	init = true;
}

Renderer::~Renderer()
{
	glDeleteTextures(1, &shadowTex);
	glDeleteFramebuffers(1, &shadowFBO);
	delete camera;
	delete heightMap;
	delete quad;

	delete reflectShader;
	delete skyboxShader;
	delete lightShader;
	delete cubeShader;
	delete sceneShader;
	delete shadowShader;
	delete textShader;
	delete emitterShader;

	delete hellData;
	delete hellNode;
	
	delete root;
	delete basicFont;
	delete emitter;

	CubeRobot::DeleteCube();
	currentShader = NULL;

}

void Renderer::UpdateScene(float msec) {
	//Whether the scene is pause
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_PAUSE)) {
		if (pause == true)
			pause = false;
		else if(pause==false)
			pause = true;
	}
	if (pause == false) {
		UpdateCamera();
		UpdateKnight();
		camera->UpdateCamera(msec);
		waterRotate += msec / 100.0f;
		hellNode->Update(msec);
		root->Update(msec);
		emitter->Update(msec);
		UpdateLight(flight);
		UpdateCameraAuto(msec);
		viewMatrix = camera->BuildViewMatrix();
	}
	else {
		viewMatrix = camera->BuildViewMatrix();
	}
	
}

void Renderer::RenderScene() {
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	CalculateFrameRate();


	DrawSkybox();
	DrawFps();
	DrawCube();
	DrawWater();
	DrawShadowScene();
	DrawCombineScene();
	DrawEmitter();


	glUseProgram(0);
	SwapBuffers();
}

void Renderer::DrawSkybox() {
	glDepthMask(GL_FALSE);
	SetCurrentShader(skyboxShader);

	UpdateShaderMatrices();
	quad->Draw();

	glUseProgram(0);
	glDepthMask(GL_TRUE);
}

void Renderer::DrawHeightmap() {
	SetCurrentShader(lightShader);
	SetShaderLight(*flight);
	
	glUniform3fv(glGetUniformLocation(currentShader->GetProgram(), "cameraPos"), 1, (float*)&camera->GetPosition());
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "diffuseTex"), 0);
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "bumpTex"), 1);

	modelMatrix.ToIdentity();
	textureMatrix.ToIdentity();


	UpdateShaderMatrices();
	heightMap->Draw();

	glUseProgram(0);
}

void Renderer::DrawWater() {
	//glEnable(GL_FRAMEBUFFER_SRGB);
	SetCurrentShader(reflectShader);
	SetShaderLight(*flight);
	glUniform3fv(glGetUniformLocation(currentShader->GetProgram(), "cameraPos"), 1, (float*)&camera->GetPosition());
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "diffuseTex"), 0);
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "cubeTex"), 2);

	/*glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_CUBE_MAP, cubeMap);*/

	float heightX = (RAW_WIDTH*HEIGHTMAP_X / 2.0f);
	float heightY = 256 * HEIGHTMAP_Y / 3.0f;
	float heightZ = (RAW_HEIGHT*HEIGHTMAP_Z / 2.0f);

	modelMatrix = Matrix4::Translation(Vector3(heightX, heightY, heightZ))*Matrix4::Scale(Vector3(heightX, 1, heightZ))*Matrix4::Rotation(90, Vector3(1.0f, 0.0f, 0.0f));

	textureMatrix = Matrix4::Scale(Vector3(10.0f, 10.0f, 10.0f))*Matrix4::Rotation(waterRotate, Vector3(0.0f, 0.0f, 1.0f));

	UpdateShaderMatrices();

	quad->Draw();
	glUseProgram(0);
	//glDisable(GL_FRAMEBUFFER_SRGB);

}

void Renderer::DrawShadowScene() {
	glBindFramebuffer(GL_FRAMEBUFFER, shadowFBO);

	glClear(GL_DEPTH_BUFFER_BIT);

	glViewport(0, 0, SHADOWSIZE, SHADOWSIZE);
	glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
	SetCurrentShader(shadowShader);
	viewMatrix = Matrix4::BuildViewMatrix(flight->GetPosition(), Vector3(2500, 300, 2000));
	textureMatrix = biasMatrix*(projMatrix*viewMatrix);

	modelMatrix.ToIdentity();
	UpdateShaderMatrices();
	
	DrawMesh();
	
	glUseProgram(0);
	glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	glViewport(0, 0, width, height);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void Renderer::DrawMesh() {
	
	modelMatrix.ToIdentity();
	modelMatrix = Matrix4::Translation(Vector3(2500, 300, 2000))*Matrix4::Scale(Vector3(3, 3, 3))*Matrix4::Rotation(0, Vector3(1.0f, 0.0f, 0.0f));

	Matrix4 tempMatrix = textureMatrix*modelMatrix;
	glUniformMatrix4fv(glGetUniformLocation(currentShader->GetProgram(), "textureMatrix"), 1, false, *&tempMatrix.values);
	glUniformMatrix4fv(glGetUniformLocation(currentShader->GetProgram(), "modelMatrix"), 1, false, *&modelMatrix.values);

	hellNode->Draw(*this);

}

void Renderer::DrawCombineScene() {
	SetCurrentShader(sceneShader);
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "diffuseTex"), 0);
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "bumpTex"), 1);
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "shadowTex"), 2);
	glUniform3fv(glGetUniformLocation(currentShader->GetProgram(), "cameraPos"), 1, (float*)&camera->GetPosition());

	SetShaderLight(*flight);

	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, shadowTex);

	viewMatrix = camera->BuildViewMatrix();
	modelMatrix.ToIdentity();
	UpdateShaderMatrices();
	Matrix4 tempMatrix = textureMatrix*modelMatrix;
	glUniformMatrix4fv(glGetUniformLocation(currentShader->GetProgram(), "textureMatrix"), 1, false, *&tempMatrix.values);
	
	heightMap->Draw();
	//DrawFloor();
	DrawMesh();


	glUseProgram(0);
}

//DrawSphere
void Renderer::DrawCube() {

	SetCurrentShader(cubeShader);

	glUseProgram(currentShader->GetProgram());
	UpdateShaderMatrices();

	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "diffuseTex"), 1);
	DrawNode(root);

	glUseProgram(0);
}

void Renderer::DrawNode(SceneNode*n) {
	SetCurrentShader(reflectShader);
	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_CUBE_MAP, cubeMap);
	if (n->GetMesh()) {
		Matrix4 transform = n->GetWorldTransform()* Matrix4::Scale(n->GetmodelScale());
		glUniformMatrix4fv(glGetUniformLocation(currentShader->GetProgram(), "modelMatrix"), 1, false, (float*)&transform);
		glUniform4fv(glGetUniformLocation(currentShader->GetProgram(), "nodeColour"), 1, (float*)&n->GetColour());
		glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "useTexture"), (int)n->GetMesh()->GetTexture());
		n->Draw(*this);
	}

	for (vector<SceneNode*>::const_iterator i = n->GetChildIteratorStart(); i != n->GetChildIteratorEnd(); ++i) {
		DrawNode(*i);

	}
}

//DrawText
void Renderer::DrawText(const std::string &text, const Vector3 &position, const float size, const bool perspective) {
	//Create a new temporary TextMesh, using our line of text and our font
	TextMesh* mesh = new TextMesh(text, *basicFont);

	//This just does simple matrix setup to render in either perspective or
	//orthographic mode, there's nothing here that's particularly tricky.
	if (perspective) {
		modelMatrix = Matrix4::Translation(position) * Matrix4::Scale(Vector3(size, size, 1));
		viewMatrix = camera->BuildViewMatrix();
		//projMatrix = Matrix4::Perspective(1.0f, 10000.0f, (float)width / (float)height, 45.0f);
		projMatrix = Matrix4::Perspective(1.0f, 10000.0f, (float)width / (float)height, 45.0f);
	}
	else {
		//In ortho mode, we subtract the y from the height, so that a height of 0
		//is at the top left of the screen, which is more intuitive
		//(for me anyway...)
		modelMatrix = Matrix4::Translation(Vector3(position.x, height - position.y, position.z)) * Matrix4::Scale(Vector3(size, size, 1));
		viewMatrix.ToIdentity();
		projMatrix = Matrix4::Orthographic(-1.0f, 1.0f, (float)width, 0.0f, (float)height, 0.0f);
	}
	//Either way, we update the matrices, and draw the mesh
	UpdateShaderMatrices();
	mesh->Draw();

	delete mesh; //Once it's drawn, we don't need it anymore!
}

void Renderer::DrawFps() {
	SetCurrentShader(textShader);
	textureMatrix.ToIdentity();
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);		// Clear Screen And Depth Buffer
	
	glUseProgram(currentShader->GetProgram());	//Enable the shader...
												//And turn on texture unit 0
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "diffuseTex"), 0);

	//Render function to encapsulate our font rendering!
	DrawText("FPS:"+str_fps, Vector3(0, 0, 0), 16.0f);
	DrawText("", Vector3(0, 0, -1000), 64.0f, true);

	glUseProgram(0);	//That's everything!
	//SwapBuffers();

}

void Renderer::CalculateFrameRate()
{
	static float framesPerSecond = 0.0f;       // This will store our fps
	static float lastTime = 0.0f;       // This will hold the time from the last frame
	float currentTime = GetTickCount() * 0.001f;
	++framesPerSecond;
	if (currentTime - lastTime > 1.0f)
	{
		lastTime = currentTime;
		str_fps = std::to_string(framesPerSecond);
		framesPerSecond = 0;
	}
}

void Renderer::SetShaderParticleSize(float f) {
	glUniform1f(glGetUniformLocation(emitterShader->GetProgram(), "particleSize"), f);
}

void Renderer::DrawEmitter() {
	Vector3 p = camera->GetPosition();
	p.y = p.y + 100;
	glClearColor(0, 0, 0, 1);
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	SetCurrentShader(emitterShader);
	glUniform1i(glGetUniformLocation(currentShader->GetProgram(), "diffuseTex"), 0);
	//glUseProgram(emitterShader->GetProgram());
	//glUniform1i(glGetUniformLocation(emitterShader->GetProgram(), "diffuseTex"), 0);
	modelMatrix = Matrix4::Translation(p)*Matrix4::Scale(Vector3(3, 3, 3))*Matrix4::Rotation(0, Vector3(1.0f, 0.0f, 0.0f));
	SetShaderParticleSize(emitter->GetParticleSize());
	emitter->SetParticleSize(10.0f);
	emitter->SetParticleVariance(1.0f);
	emitter->SetLaunchParticles(16.0f);
	emitter->SetParticleLifetime(2000.0f);
	emitter->SetParticleSpeed(0.1f);
	UpdateShaderMatrices();

	emitter->Draw();

	
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glUseProgram(0);
	//SwapBuffers();
}

//Change the Light position & colour & skybox
void Renderer::UpdateLight(Light* l) {
	//Get the position of the sphere
	for (auto it = lightSphere->GetChildIteratorStart(); it != lightSphere->GetChildIteratorEnd(); ++it) {
		newPos = (lightSphere->GetWorldTransform() * (*it)->GetTransform()).GetPositionVector();
	}
	
	//Set the position of the Light
	l->SetPosition(newPos);
	//if press 'L'
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_L)) {
		if (Lightcount == 0) {
			l->SetColour(Vector4(1, 0, 0, 1));
			cubeMap = SOIL_load_OGL_cubemap(TEXTUREDIR"mercury_ft.tga",
				TEXTUREDIR"mercury_bk.tga",
				TEXTUREDIR"mercury_up.tga",
				TEXTUREDIR"mercury_dn.tga",
				TEXTUREDIR"mercury_rt.tga",
				TEXTUREDIR"mercury_lf.tga",
				SOIL_LOAD_RGB, SOIL_CREATE_NEW_ID, 0);
			DrawSkybox();
			Lightcount = 1;
		}
		else if (Lightcount == 1) {
			l->SetColour(Vector4(0, 1, 0, 1));
			cubeMap = SOIL_load_OGL_cubemap(TEXTUREDIR"green_ft.tga",
				TEXTUREDIR"green_bk.tga",
				TEXTUREDIR"green_up.tga",
				TEXTUREDIR"green_dn.tga",
				TEXTUREDIR"green_rt.tga",
				TEXTUREDIR"green_lf.tga",
				SOIL_LOAD_RGB, SOIL_CREATE_NEW_ID, 0);
			DrawSkybox();
			Lightcount = 2;
		}
		else if (Lightcount == 2) {
			l->SetColour(Vector4(0.5, 0.5, 1, 1));
			cubeMap = SOIL_load_OGL_cubemap(TEXTUREDIR"bluefreeze_ft.tga",
				TEXTUREDIR"bluefreeze_bk.tga",
				TEXTUREDIR"bluefreeze_up.tga",
				TEXTUREDIR"bluefreeze_dn.tga",
				TEXTUREDIR"bluefreeze_rt.tga",
				TEXTUREDIR"bluefreeze_lf.tga",
				SOIL_LOAD_RGB, SOIL_CREATE_NEW_ID, 0);
			DrawSkybox();
			Lightcount = 3;
		}
		else if (Lightcount == 3) {
			l->SetColour(Vector4(1, 1, 1, 1));
			cubeMap = SOIL_load_OGL_cubemap(TEXTUREDIR"rusted_west.jpg",
				TEXTUREDIR"rusted_east.jpg",
				TEXTUREDIR"rusted_up.jpg",
				TEXTUREDIR"rusted_down.jpg",
				TEXTUREDIR"rusted_south.jpg",
				TEXTUREDIR"rusted_north.jpg",
				SOIL_LOAD_RGB, SOIL_CREATE_NEW_ID, 0);
			DrawSkybox();
			Lightcount = 0;
		}
	}
}

//Change the move of hellKnight
void Renderer::UpdateKnight() {
	//Change HellKnight
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_B)) {
		hellData->AddAnim(MESHDIR"attack2.md5anim");
		hellNode->PlayAnim(MESHDIR"attack2.md5anim");
	}
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_I)) {
		hellData->AddAnim(MESHDIR"idle2.md5anim");
		hellNode->PlayAnim(MESHDIR"idle2.md5anim");
	}
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_G)) {
		hellData->AddAnim(MESHDIR"walk7.md5anim");
		hellNode->PlayAnim(MESHDIR"walk7.md5anim");
	}
}

//Change the position of Camera
void Renderer::UpdateCamera() {
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_1)) {
		camera->SetPosition(Vector3(2120, 9600, 2600));
		camera->SetPitch(-90.0f);
		camera->SetYaw(0.0f);
		camPos = 0;
	}
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_2)) {
		camera->SetPosition(Vector3(-200, 500, 4200));
		camera->SetPitch(0.0f);
		camera->SetYaw(-30.0f);
		camPos = 1;
	}
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_3)) {
		camera->SetPosition(Vector3(6000, 4000, -300));
		camera->SetYaw(-230.0f);
		camera->SetPitch(-45.0f);
		camPos = 2;
	}
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_4)) {
		camera->SetPosition(Vector3(0, 500, 0));
		camera->SetPitch(0.0f);
		camera->SetYaw(-135.0f);
		camPos = 3;
	}

	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_LEFT)) {
		if(camPos==0){
			camera->SetPosition(Vector3(-200, 500, 4200));
			camera->SetPitch(0.0f);
			camera->SetYaw(-30.0f);
			camPos = 1;
		}
		else if (camPos == 1){
			camera->SetPosition(Vector3(6000, 4000, -300));
			camera->SetYaw(-230.0f);
			camera->SetPitch(-45.0f);
			camPos = 2;
		}
		else if (camPos == 2){
			camera->SetPosition(Vector3(0, 500, 0));
			camera->SetPitch(0.0f);
			camera->SetYaw(-135.0f);
			camPos = 3;
		}
		else if (camPos == 3) {
			camera->SetPosition(Vector3(2120, 9600, 2600));
			camera->SetPitch(-90.0f);
			camera->SetYaw(0.0f);
			camPos = 0;
		}
	}
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_RIGHT)) {
		if (camPos == 0) {
			camera->SetPosition(Vector3(0, 500, 0));
			camera->SetPitch(0.0f);
			camera->SetYaw(-135.0f);
			camPos = 3;
		}
		else if (camPos == 1) {
			camera->SetPosition(Vector3(2120, 9600, 2600));
			camera->SetPitch(-90.0f);
			camera->SetYaw(0.0f);
			camPos = 0;
		}
		else if (camPos == 2) {
			camera->SetPosition(Vector3(-200, 500, 4200));
			camera->SetPitch(0.0f);
			camera->SetYaw(-30.0f);
			camPos = 1;
		}
		else if (camPos == 3) {
			camera->SetPosition(Vector3(6000, 4000, -300));
			camera->SetYaw(-230.0f);
			camera->SetPitch(-45.0f);
			camPos = 2;
		}

	}
}

//Change the position of Camera automatically
void Renderer::UpdateCameraAuto(float msec) {
	if (Window::GetKeyboard()->KeyTriggered(KEYBOARD_C))
	{
		if (camauto == true) {
			camauto = false;
		}
		else if (camauto == false) {
			camauto = true;
		}
	}
	msec *= 5.0f;
	Vector3 camPos = camera->GetPosition();
	float camYaw = camera->GetYaw();
	
	if (camauto == false) {

	}
	else if (camauto == true) {
		camPos -= Matrix4::Rotation(camYaw, Vector3(0, 0.1f, 0)) * Vector3(-0.1f, 0, 0) * msec;
		//camYaw -= (Window::GetMouse()->GetRelativePosition().x);
		camYaw = camYaw + 0.2f;
		if (camYaw <0) {
			camYaw += 360.0f;
		}
		if (camYaw > 360.0f) {
			camYaw -= 360.0f;
		}
		
		camera->SetPosition(camPos);
		camera->SetYaw(camYaw);
	}
}


