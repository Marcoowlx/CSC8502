#include "CubeRobot.h"

Mesh* CubeRobot::cube = NULL;

CubeRobot::CubeRobot(void)
{

	SceneNode* body = new SceneNode(cube, Vector4(1, 1, 1, 1));
	body->SetModelScale(Vector3(500, 500, 500));
	body->SetTransform(Matrix4::Translation(Vector3(2000, 0, 0)));
	AddChild(body);
	

}


void CubeRobot::Update(float msec) {
	transform = transform*Matrix4::Rotation(msec / 20.0f, Vector3(0, 1, 0));
	

	SceneNode::Update(msec);
}
