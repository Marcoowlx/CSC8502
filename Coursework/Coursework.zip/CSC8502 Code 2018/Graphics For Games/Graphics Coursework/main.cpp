﻿#pragma comment(lib, "nclgl.lib")

#include "../../nclgl/window.h"
#include "renderer.h"

bool change = false;

int main() {
	Window w("Course Work", 1920,1080,true);
	if (!w.HasInitialised()) {
		return -1;
	}

	Renderer renderer(w);

	if (!renderer.HasInitialised()) {
		return -1;
	}


	w.LockMouseToWindow(true);
	w.ShowOSPointer(false);
	
	while (w.UpdateWindow() && !Window::GetKeyboard()->KeyDown(KEYBOARD_ESCAPE)) {
		/*if (Window::GetKeyboard()->KeyDown(KEYBOARD_1)) {
		}*/
			renderer.UpdateScene(w.GetTimer()->GetTimedMS());
			renderer.RenderScene();

		
	}
	return 0;
	

}